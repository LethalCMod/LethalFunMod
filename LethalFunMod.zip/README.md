# Pre Alpha v1.0.0
### [v1.0.0] [For Lethal Company v45] Lethal FunMod is a modpack with over 40 Mods!

<img src="https://cdn.discordapp.com/attachments/1188859656437760111/1188863155930140886/image.png?ex=659c1218&is=65899d18&hm=aabdbc36b49ba4be4024aaddde407668f73501ab62f7de9e4f401371dc8566d9&">

---

# RELEASE OUT NOW! v1.0.0

### *Features*

- Ideal for 4-8 players or more!

- Adds new content to the game!

- And much more!

---

# Check out my other modpack!

<a href="https://thunderstore.io/c/lethal-company/p/Lethal_CMod/Lethal_CMod/" target="_blank">Lethal CMod</a>

---
### *Weekly Updates*!
#### On new version releases, we recommend reinstalling the modpack!
Just download it from 
<a href="https://thunderstore.io/package/Lethal_CMod/?section=modpacks" target="_blank">Thunderstore</a>
or from our <a href="https://github.com/LethalCMod">GitHub</a> website.

---
### *Report Bugs*!

Report bugs or suggest improvements by <a href="https://github.com/LethalCMod/Lethal-CMod-/issues" target="_blank">creating an issue</a> or via the <a href="https://github.com/LethalCMod/Lethal-CMod-/issues/new" target="_blank">direct link</a>!

---
### *Update Calendar*
<details>

<summary>Click here to view all updates in order.</summary>

- ##### 31.12.2023 [v1.1.0] Patch 1

- ##### 5.1.2024 [v1.2.0] Patch 2

- #### 12.1.2024 [v1.3.0]~~ Early Access Update

- #### More coming soon!
</details>

---
### *Update Log*
<details>
<summary>Click here to view all changes in order.</summary>

### v1.0.0
```
- Release
```

</details>

---